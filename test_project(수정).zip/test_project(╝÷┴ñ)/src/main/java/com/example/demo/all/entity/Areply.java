package com.example.demo.all.entity;

import java.time.*;

import lombok.*;


@Getter
@Builder
@ToString
public class Areply {

	private Integer aReplyNum;
	private String aReplyContent;
	private Integer aReviewNum;
	
	private LocalDateTime aReplyDate;
}
