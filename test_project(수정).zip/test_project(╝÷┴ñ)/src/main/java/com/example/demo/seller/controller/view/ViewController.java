package com.example.demo.seller.controller.view;

import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

@Controller
public class ViewController {
	
	@GetMapping(value = "seller/main/main")
	public void main () {
	}
	
	@GetMapping(value = "seller/testgroup")
	public void testgroup() {
	}
	
	@GetMapping(value = "seller/testhome")
	public void testhome() {
	}
	
	@GetMapping(value = "seller/testmenu")
	public void testmenu() {
	}
}
