package com.example.demo.consumer.exception;

public class ConsumerNotFoundException extends RuntimeException{

}
