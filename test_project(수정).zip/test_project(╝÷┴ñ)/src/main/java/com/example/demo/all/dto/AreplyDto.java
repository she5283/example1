package com.example.demo.all.dto;

import java.time.*;
import java.util.*;

import com.example.demo.all.entity.*;

import lombok.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AreplyDto {

	@Data
	@Builder
	public static class Write {
		private Integer aReplyNum;
		private String aReplyContent;
		
		private LocalDate aReplyDate;
		
		public Areply toEntity() {
			return Areply.builder().aReplyNum(aReplyNum).aReplyContent(aReplyContent).build();
		}
	}
	
	@Data
	public static class Read {
		private Integer aReplyNum;
		private String aReplyContent;
		
		
		private LocalDate aReplyDate;
	}
	
	@Data
	public static class ForList {
		private Integer aReplyNum;
		private String aReplyContent;
		private LocalDate aReplyDate;
		private Integer aReviewNum;
		
		private Collection<ForList> reviews;
	}
}
