package com.example.demo.all.dto;

import java.time.*;
import java.util.*;

import com.example.demo.all.entity.*;

import lombok.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AreplyDto {

	@Data
	@Builder
	public static class Write {
		private Integer aReplyNum;
		private String aReplyContent;
		
		private LocalDateTime aReplyDate;
		
		public Areply toEntity() {
			return Areply.builder().aReplyNum(aReplyNum).aReplyContent(aReplyContent).build();
		}
	}
	
	@Data
	public static class Read {
		private Integer aReplyNum;
		private String aReplyContent;
		
		
		private LocalDateTime aReplyDate;
	}
	
	@Data
	public static class ForList {
		private Integer aReplyNum;
		private String aReplyContent;
		private LocalDateTime aReplyDate;
		private Integer aReviewNum;
		
		private Collection<ForList> reviews;
	}
	
	@Data
	public static class Update {
		private Integer aReplyNum;
		private String aReplyContent;
		
		private LocalDateTime aReplyDate;
	}
}
