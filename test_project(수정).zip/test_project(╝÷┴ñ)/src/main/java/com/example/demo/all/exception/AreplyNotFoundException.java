package com.example.demo.all.exception;

public class AreplyNotFoundException extends RuntimeException {

}
