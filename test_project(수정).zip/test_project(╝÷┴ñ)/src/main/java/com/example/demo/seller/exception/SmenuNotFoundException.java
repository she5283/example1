package com.example.demo.seller.exception;

public class SmenuNotFoundException extends RuntimeException{

}
