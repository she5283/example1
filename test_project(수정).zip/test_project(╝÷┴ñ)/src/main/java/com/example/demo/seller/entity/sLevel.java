package com.example.demo.seller.entity;

public enum sLevel {
	BRONZE, SILVER, GOLD;
}
