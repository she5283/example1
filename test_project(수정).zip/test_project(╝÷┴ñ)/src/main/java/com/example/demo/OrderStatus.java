package com.example.demo;

public enum OrderStatus {
	주문취소, 접수대기, 접수완료, 배달중, 배달완료;
}
