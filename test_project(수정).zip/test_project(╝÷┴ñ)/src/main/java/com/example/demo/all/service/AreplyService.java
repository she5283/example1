package com.example.demo.all.service;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.example.demo.all.dao.*;
import com.example.demo.all.dto.*;
import com.example.demo.all.entity.*;

@Service
public class AreplyService {
	
	@Autowired
	private AreplyDao areplyDao;
	
	public void write(AreplyDto.Write dto) {
		Areply aReply = dto.toEntity();
		areplyDao.replySave(aReply);
	}
}
