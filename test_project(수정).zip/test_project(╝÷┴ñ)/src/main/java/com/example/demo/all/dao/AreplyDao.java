package com.example.demo.all.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.all.dto.*;
import com.example.demo.all.entity.*;

@Mapper
public interface AreplyDao {
	
	// 답글 작성
	public Integer replySave(Areply aReply);
	
	// 답글 출력
	public Optional<AreplyDto.Read> replyRead(Integer aReplyNum);
	
	// 답글 수정
	public Integer replyUpdate(Areply aReply);
	
	// 답글 삭제
	public Integer replyDelete(Integer aReplyNum);
	
	// 가게 리뷰 출력
	public List<AreplyDto.ForList> storeReviewList(String sStoreNum);
}
