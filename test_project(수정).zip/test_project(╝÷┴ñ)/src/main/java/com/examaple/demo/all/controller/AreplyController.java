package com.examaple.demo.all.controller;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.security.access.prepost.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.all.dto.*;
import com.example.demo.all.service.*;
import com.example.demo.seller.dto.*;

@Controller
public class AreplyController {
	
	@Autowired
	private AreplyService service;
	
//	@PreAuthorize("isAuthenticated()")
	@PostMapping(value = "seller/areply/new", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> write(AreplyDto.Write dto) {
		service.write(dto);
		return ResponseEntity.ok(new RestResponse("OK", "추가가 완료되었습니다.", null));
	}
	
//	@PreAuthorize("isAuthenticated()")
	@GetMapping(value = "seller/areply/read", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> read(Integer aReplyNum) {
		return ResponseEntity.ok(new RestResponse("OK", service.read(aReplyNum), null));
	}
	
//	@PreAuthorize("isAuthenticated()")
	@PutMapping(value = "seller/areply/update", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> update(AreplyDto.Update dto) {
		service.update(dto);
		return ResponseEntity.ok(new RestResponse("OK", "변경이 완료되었습니다.", null));
	}
	
//	@PreAuthorize("isAuthenticated()")
	@DeleteMapping(value = "seller/areply/delete", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> delete(Integer aReplyNum) {
		service.delete(aReplyNum);
		return ResponseEntity.ok(new RestResponse("OK", "삭제가 완료되었습니다.", null));
	}
}
