// 서버에서 가게번호 가져오기
function getstoreNum() {
	const storeNum = location.search.substring(11)
	if (isNaN(storeNum)) {
		alert("가게를 찾을 수 없습니다");
		location.reload();
	}
	return storeNum;
}

// 메뉴 그룹 출력 (메뉴 추가 버튼 출력)
async function printgroup(group) {
	const grouplist = await $.ajax({
		url: "/seller/menu/group/all",
		data: { sStoreNum: group }
	})
	for (const mgl of grouplist) {
		const $li = $("<li>").text(mgl.sgroupName).attr("value1", mgl.sgroupNum).attr("value2", "show").attr("class", "menugroup").appendTo("#menegroup");
		$("<button>").text("메뉴 추가").attr("class", "modal_menu_in").attr("value", mgl.sgroupNum).appendTo($li);
		$("<ul>").attr("class", "menulist").appendTo($li);
	}
	return grouplist;
}

$(document).ready(async function() {

	const imgurl = "https://s3.ap-northeast-2.amazonaws.com/iciasmartframe2/upload/seller/menuimg/"

	const sid = 'test1';

	const storeNum = getstoreNum();
	const a = await printgroup(storeNum);

	console.log(a);

	// 메뉴 리스트 출력 값 넣기
	$(document).on("click", ".menugroup", async function() {
		if ($(this).attr("value2") == "show") {

			const groupnum = $(this).attr("value1")
			const result = await $.ajax({
				url: "/seller/menu/all",
				data: { sGroupNum: groupnum }
			})

			const menuresult = result.result;

			const $group = $(this).children('.menulist');

			for (const ml of menuresult) {
				const $li = $("<li>").attr("value1", ml.sgroupNum).attr("value2", ml.smenuCode).attr("class", "listli").appendTo($group);
				$("<span>").text(ml.smenuImg).appendTo($li);
				$("<span>").text("메뉴 : " + ml.smenuName).appendTo($li);
				$("<span>").text("가격 : " + ml.smenuPrice).appendTo($li);
			}

			$(this).attr("value2", "hide");
		} else {
			$(this).children().children().remove();

			$(this).attr("value2", "show");
		}
	})

	// 벨류 값 가져오기
	$(document).on("click", ".listli", async function(e) {
		e.stopPropagation();

		const groupnum = $(this).attr("value1");
		const menucode = $(this).attr("value2");
	})

	// 모달 출력 시 가게번호 가져가기
	$(document).on("click", ".modal_group_in", async function() {
		$("#sStoreNum").attr("value", storeNum);
		$(".modal_group").fadeIn();
	});

	// 모달 닫기
	$(document).on("click", ".modal_group_Out", function() {
		$(".modal_group").fadeOut();
	});

	// 모달 메뉴 그룹 추가
	$(document).on("click", "#write_group", async function() {
		const param = {
			sId: 'test1',
			sStoreNum: $("#sStoreNum").val(),
			sGroupName: $("#sGroupName").val()
		}

		const result = await $.ajax({
			url: "/seller/menu/group/new",
			method: "post",
			data: param,
			success: function() {
				location.href = location.href
			}
		})
		$(".modal_group").fadeOut();

	})

	// 모달 출력 시 메뉴그룹번호 가져가기
	$(document).on("click", ".modal_menu_in", function(e) {
		e.stopPropagation();

		const groupnum = $(this).attr("value");

		$("#sGroupNum").attr("value", groupnum);

		$(".modal_menu").fadeIn();
	})

	// 메뉴 그룹에 메뉴 추가
	$(document).on("click", "#write_menu", function() {

		const formData = new FormData($("#write_menu_form")[0]);

		const result = $.ajax({
			url: "/seller/menu/new",
			method: "post",
			data: formData,
			processData: false,
			contentType: false,
			success: function() {
				location.href = location.href
			}
		});
		console.log(result);

		$(".modal_menu").fadeOut();
	})

	// 메뉴 취소
	$(document).on("click", ".modal_menu_Out", function() {
		$(".modal_menu").fadeOut();
	})

	// 이미지 선택 시 미리보기
	let fileTag = document.querySelector("input[name=sMenuImg]");

	fileTag.onchange = function() {

		let imgTag = document.querySelector("#profileImg");

		if (fileTag.files.length > 0) {

			let reader = new FileReader();

			reader.onload = function(data) {
				console.log(data);
				imgTag.src = data.target.result;
				imgTag.width = 250;
				imgTag.height = 150;
			}

			reader.readAsDataURL(fileTag.files[0]);
		} else {

			imgTag.src = "";
		}
	}
})