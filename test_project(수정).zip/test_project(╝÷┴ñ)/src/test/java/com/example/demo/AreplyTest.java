package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;

import com.example.demo.all.dto.*;
import com.example.demo.all.entity.*;
import com.example.demo.all.service.*;

@SpringBootTest
public class AreplyTest {

	@Autowired
	private AreplyService service;
	
	public void save() {
		AreplyDto.Write dto = AreplyDto.Write.builder().aReplyContent("테스트").build();
	}
}
