package com.example.demo.seller.dto;

import lombok.*;

@Data
@AllArgsConstructor
public class RestResponse {
	private String message;
	
	private Object result;
	
	private String url;
}
