package com.example.demo.seller.dto;

import java.time.*;

import javax.validation.constraints.*;

import com.example.demo.seller.entity.*;

import lombok.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SellerDto {

	@Data
	@Builder
	public static class Join{
		@Pattern(regexp = "^[a-zA-Z0-9]{8,15}$", message = "아이디는 대문자,소문자,숫자 8~15자입니다.")
		private String sId;
		
		private String sPassword;
		
		private String sName;
		
		private String sEmail;
		
		private Integer sBusinessNum;
		
		private Integer sPhone;
		
		private String sBirth;

		public Seller toEntity() {
			return Seller.builder().sId(sId).sEmail(sEmail).sPassword(sPassword).sName(sName).sBusinessNum(sBusinessNum).sPhone(sPhone).build();
		}
	}
	
	@Data
	public static class IdCheck {
		@Pattern(regexp = "^[a-zA-Z0-9]{8,15}$", message = "아이디는 대문자,소문자,숫자 8~15자입니다.")
		private String sId;
	}
	
	@Data
	public static class EmailCheck {
		@Email
		private String sEmail;
	}
	
	@Data
	public static class FindId {
//		@NotEmpty(message = "이메일은 필수입력입니다")
		@Email(message = "잘못된 이메일 형식입니다")
		private String sEmail;
	}
	
	@Data
	public static class ResetPassword {
//		@NotEmpty(message = "아이디는 필수입력입니다.")
		private String sId;
		
		@Email
//		@NotEmpty(message = "이메일은 필수입력입니다.")
		private String sEmail;
	}
	
	@Data
	public static class ChangePassword {
//		@NotEmpty(message = "비밀번호는 필수입력입니다.")
		private String sPassword;
		
//		@NotEmpty(message = "비밀번호는 필수입력입니다.")
		private String newPassword;
	}
	
	@Data
	@Builder
	public static class Read {
		private String sId;
		private String sName;
		private Integer sBusinessNum;
		private Integer sPhone;
		private String sEmail;
		
		private LocalDate sBirth;
		private LocalDate joinday;
		private Long days;
	}
	
	@Data
	@Builder
	public static class Update {
		private String sEmail;
	}
}
