package com.example.demo.seller.dto;

public class SellerDto {

}
