package com.example.demo.seller.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.seller.entity.*;

@Mapper
public interface SellerDao {
	
	// 회원가입
	public Integer memberJoin(Seller seller);
	
	// 내 정보 수정
	public Integer memberUpdate(Seller seller);
	
	// 내 정보 출력
	public Optional<Seller> memberInforList(Seller seller);
	
	// 아이디 중복 확인
	public Boolean idCheck(String sId);
	
	// 이메일 중복 확인
	public Boolean emailCheck(String sEmail);
	
	// 사업자번호 중복 확인
	public Boolean businessNoCheck(Integer sBusinessNum);
	
	// 아이디 찾기
	public Optional<Seller> findById(String sId);
	
	// 비밀번호 찾기 하면 이메일로 임시 비밀번호 전송
//	public findByEmail();
	
	// 이메일 인증
//	public Optional<Seller> emailCertifed(String sEmail);
	
	// 회원 탈퇴
	public Integer memberClear(String sId);
}
