package com.example.demo.seller.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.seller.entity.*;

@Mapper
public interface SellerDao {
	
	// 회원가입
	public Integer memberJoin(Seller seller);
	
	// 내 정보 수정
	public Integer memberUpdate(Seller seller);
	
	// 내 정보 출력
//	public Optional<Seller> memberInforList(Seller seller);
	
	// 아이디 중복 확인
	public Boolean idCheck(String sId);
	
	// 이메일 중복 확인
	public Boolean emailCheck(String sEmail);
	
	// 사업자번호 중복 확인
	public Boolean businessNoCheck(Integer sBusinessNum);
	
	// 비밀번호 찾기 내 정보 가져오기
	public Optional<Seller> findById(String sId);
	
	// 이메일로 아이디 찾기
	public Optional<Seller> findByEmail(String sEmail);
	
	// 회원 탈퇴
	public Integer deleteById(String sId);

	// 체크 코드 전송
	public Optional<Seller> findByCheckcode(String checkcode);

	// 체크 코드 확인
	public List<String> findByCheckcodeIsNotEmpty();

	// 체크코드 확인하지 않은 아이디 삭제
	public Integer deleteBysId(List<String> sId);
}
