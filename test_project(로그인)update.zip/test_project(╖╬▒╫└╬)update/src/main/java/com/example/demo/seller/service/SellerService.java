package com.example.demo.seller.service;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.crypto.password.*;
import org.springframework.stereotype.*;

import com.example.demo.seller.dao.*;
import com.example.demo.seller.util.*;

@Service
public class SellerService {
	
	@Autowired
	private SellerDao sDao;
	@Autowired
	private MailUtil mailUtil; 
	@Autowired
	private PasswordEncoder passwordEncoder;
	
}
