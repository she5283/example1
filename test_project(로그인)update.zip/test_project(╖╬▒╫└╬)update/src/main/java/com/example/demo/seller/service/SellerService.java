package com.example.demo.seller.service;

import java.time.*;
import java.time.temporal.*;
import java.util.*;

import javax.annotation.*;

import org.apache.commons.lang3.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.scheduling.annotation.*;
import org.springframework.security.crypto.password.*;
import org.springframework.stereotype.*;

import com.example.demo.seller.dao.*;
import com.example.demo.seller.dto.*;
import com.example.demo.seller.dto.SellerDto.*;
import com.example.demo.seller.entity.*;
import com.example.demo.seller.exception.*;
import com.example.demo.seller.util.*;

@Service
public class SellerService {
	
	@Autowired
	private SellerDao sDao;
	@Autowired
	private MailUtil mailUtil; 
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	// 아이디 중복 확인
	public void idAvailable(String sId) {
		if(sDao.idCheck(sId))
			throw new JobFailException("사용중인 아이디입니다.");
	}
	
	// 이메일 중복 확인
	public void emailAvailable(String sEmail) {
		if(sDao.emailCheck(sEmail))
			throw new JobFailException("사용중인 이메일입니다");
	}
	
	// 사업자번호 중복 확인
	public void businessNumAvailable(Integer sBusinessNum) {
		if(sDao.businessNoCheck(sBusinessNum))
			throw new JobFailException("중복된 사업자번호입니다.");
	}
	
	// 회원 가입
	public void join(SellerDto.Join dto) {
		if(sDao.idCheck(dto.getSId()))
			throw new JobFailException("사용중인 아이디입니다.");
		
		if(sDao.emailCheck(dto.getSEmail()))
			throw new JobFailException("사용중인 이메일입니다");
		
		if(sDao.businessNoCheck(dto.getSBusinessNum()))
			throw new JobFailException("중복된 번호입니다.");
		
		Seller seller = dto.toEntity();
		
		String checkcode = RandomStringUtils.randomAlphanumeric(15);
		LocalDate date = LocalDate.parse(dto.getSBirth());
		String encodedPassword = passwordEncoder.encode(seller.getSPassword());
		seller.addJoin(date, encodedPassword);
		sDao.memberJoin(seller);
		mailUtil.sendCheckMail("seller@naver.com", seller.getSEmail(), checkcode);
	}
	
	// 이메일로 아이디 찾고 이메일로 전송
	public void findId(SellerDto.FindId dto) {
		Seller seller = sDao.findByEmail(dto.getSEmail()).orElseThrow(()-> new MemberNotFoundException());
		mailUtil.sendCheckMail("seller@naver.com", dto.getSEmail(), seller.getSId());
	}
	
	// 비밀번호 리셋
	// 아이디로 검색 -> 없으면 MemberNotFoundException
	// 이메일을 확인 -> 틀리면 MemberNotFoundException
	// 15글자 임시비밀번호 생성 -> 암호화 -> 비번 변경 -> 메일 발송
	public void resetPassword(SellerDto.ResetPassword dto) {
		Seller seller = sDao.findById(dto.getSId()).orElseThrow(()-> new MemberNotFoundException());
		if(seller.getSEmail().equals(dto.getSEmail())==false)
			throw new MemberNotFoundException();
		String newPassword = RandomStringUtils.randomAlphanumeric(15);
		sDao.memberUpdate(Seller.builder().sId(dto.getSId()).sPassword(passwordEncoder.encode(newPassword)).build());
		mailUtil.sendResetPasswordMail("seller@naver.com", dto.getSEmail(), newPassword);
	}
	
	// 비밀번호 변경
	// 아이디로 검색 -> 없으면 MemberNotFoundException
	// 비밀번호를 맞춰본다 -> passwordEncoder.matches() -> 실패하면 예외처리
	// 새비밀번호를 암호화 후 저장
	public void changePassword(SellerDto.ChangePassword dto, String loginId) {
		Seller seller = sDao.findById(loginId).orElseThrow(()-> new MemberNotFoundException());
		String encodedPassword = seller.getSPassword();
		if(passwordEncoder.matches(dto.getSPassword(), encodedPassword)==false)
			throw new JobFailException("비밀번호를 변경하지 못했습니다");
		sDao.memberUpdate(Seller.builder().sId(loginId).sPassword(passwordEncoder.encode(dto.getNewPassword())).build());
	}
	
	// 로그인 오류 체크 날짜 형식 변환
	public Read read(String loginId) {
		Seller seller = sDao.findById(loginId).orElseThrow(()-> new MemberNotFoundException());
		Read dto = seller.toDto();
		return dto;
	}
	
	// 체크코드 확인
	public void checkJoin(String checkcode) {
		Seller seller = sDao.findByCheckcode(checkcode).orElseThrow(()-> new JobFailException("체크코드를 확인할 수 없습니다"));
		sDao.memberUpdate(Seller.builder().sId(seller.getSId()).enabled(true).checkcode("").build());
	}
	
	@Scheduled(cron = "0 0 4 ? * THU")
	public void 확인하지않은가입신청삭제() {
		List<String> sIds = sDao.findByCheckcodeIsNotEmpty();
		sDao.deleteBysId(sIds);
	}
	
	// 이메일 변경
	public Integer updatte(SellerDto.Update dto, String loginId) {
		String newEmail = dto.getSEmail();
		
		Seller seller = sDao.findById(loginId).orElseThrow(()-> new MemberNotFoundException());
		if(newEmail==null)
			newEmail = seller.getSEmail();
		
		return sDao.memberUpdate(Seller.builder().sId(loginId).sEmail(newEmail).build());
	}
	
	// 회원 탈퇴
	public Integer resign(String loginId) {
		if(sDao.idCheck(loginId)==false)
			throw new MemberNotFoundException();
		return sDao.deleteById(loginId);
	}
}

