package com.example.demo.seller.controller;

import java.security.*;

import javax.servlet.http.*;
import javax.validation.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.security.access.prepost.*;
import org.springframework.security.core.*;
import org.springframework.security.web.authentication.logout.*;
import org.springframework.stereotype.*;
import org.springframework.validation.*;
import org.springframework.validation.annotation.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.seller.dto.*;
import com.example.demo.seller.service.*;

@Validated
@Controller
public class SellerController {
	
	@Autowired
	private SellerService service;
	
	@GetMapping(value="/seller/check/id", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> checkId(String sId) {
		service.idAvailable(sId);
		return ResponseEntity.ok(new RestResponse("OK", "사용 가능한 아이디입니다", null));
	}
	
	@GetMapping(value="/seller/check/email", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> checkEmail(String sEmail) {
		service.emailAvailable(sEmail);
		return ResponseEntity.ok(new RestResponse("OK", "사용 가능한 이메일입니다", null));
	}
	
	@GetMapping(value="/seller/check/businessNum", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> checkBusinessNum(Integer sBusinessNum) {
		service.businessNumAvailable(sBusinessNum);
		return ResponseEntity.ok(new RestResponse("OK", "사용할 수 있는 사업자 번호입니다", null));
	}
	
	@PostMapping(value="/seller/new", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> join(SellerDto.Join dto) {
		service.join(dto);
		return ResponseEntity.ok(new RestResponse("OK", "가입 성공", "/login"));
	}
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping(value="/seller/read", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> read(Principal principal) {
		SellerDto.Read dto = service.read(principal.getName());
		return ResponseEntity.ok(new RestResponse("Ok", dto, null));
	}
	
	@GetMapping(path="/seller/find/sId", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> findId(@Valid SellerDto.FindId dto, BindingResult bindingResult) {
		service.findId(dto);
		return ResponseEntity.ok(new RestResponse("OK", "아이디를 이메일로 보냈습니다", null));
	}
	
	@PatchMapping(path="/seller/find/password", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> resetPassword(@Valid SellerDto.ResetPassword dto, BindingResult bindingResult) {
		service.resetPassword(dto);
		return ResponseEntity.ok(new RestResponse("OK", "임시 비밀번호를 이메일로 보냈습니다", null));
	}
	
	@PreAuthorize("isAuthenticated()")
	@PatchMapping(path="/seller/password", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> changePassword(@Valid SellerDto.ChangePassword dto, BindingResult bindingResult, Principal principal) {
		service.changePassword(dto, principal.getName());
		return ResponseEntity.ok(new RestResponse("OK", "비밀번호를 변경했습니다", null));
	}
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping(path="/seller/update", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> update(@Valid SellerDto.Update dto, BindingResult bindingResult, Principal principal) {
		service.updatte(dto, principal.getName());
		return ResponseEntity.ok(new RestResponse("OK", "회원 정보를 변경했습니다", "/seller/read"));
	}
	
	@PreAuthorize("isAuthenticated()")
	@DeleteMapping(path="/seller/delete", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> resign(SecurityContextLogoutHandler handler, HttpServletRequest req, HttpServletResponse res, Authentication authentication) {
		service.resign(authentication.getName());
		handler.logout(req, res, authentication);
		return ResponseEntity.ok(new RestResponse("OK", "회원 정보를 삭제했습니다", null));
	}
}
