package com.example.demo.seller.controller;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.validation.annotation.*;

import com.example.demo.seller.service.*;

@Validated
@Controller
public class SellerController {
	
	@Autowired
	private SellerService service;
}
