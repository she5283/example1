package com.example.demo.seller.entity;

import java.time.*;

import com.example.demo.seller.dto.SellerDto.*;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
public class Seller {
	private String sId;
	private Integer sBusinessNum;
	private String sPassword;
	private String sName;
	private Integer sPhone;
	private String sEmail;
	private Boolean enabled;
	
	private String checkcode;
	private Integer sStoreNum;
	private LocalDate sBirth;
	private LocalDate joinday;
	public void addJoin(LocalDate date, String encodedPassword) {
		this.sBirth = date;
		this.sPassword = encodedPassword;
	}
	public Read toDto() {
		return Read.builder().sId(sId).sName(sName).sEmail(sEmail).sBirth(sBirth).build();
	}
}
