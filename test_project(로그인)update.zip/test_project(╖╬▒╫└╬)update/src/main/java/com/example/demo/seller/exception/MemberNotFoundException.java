package com.example.demo.seller.exception;

public class MemberNotFoundException extends RuntimeException {

}
