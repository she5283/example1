package com.example.demo.entity;

import java.time.*;

import com.example.demo.dto.*;
import com.example.demo.dto.MemberDto.*;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Member {
	private String username;		// 사용자 입력
	private String password;		// 서버에서 암호화해서 추가
	private String irum;			// 사용자 입력
	private String email;			// 사용자 입력
	private LocalDate birthday;		// 사용자 입력
	private LocalDate joinday;		// 기본값
	private String profile;			
	private String role;
	private Integer loginFailCnt;
	private Boolean enabled;		// 기본값
	private String checkcode;		// 서버에서 추가하는 값
	private Integer buyCount;		// 기본값
	private Integer buyMoney;		// 기본값
	private Level levels;
	public void addJoinInfo(String profileName, String checkcode, String encodedPassword, Level levels) {
		this.profile = profileName;
		this.checkcode = checkcode;
		this.password = encodedPassword;
		this.levels = levels;
	}
	public Read toDto() {
		return MemberDto.Read.builder().username(username).irum(irum)
			.email(email).birthday(birthday).joinday(joinday).profile(profile)
			.levels(levels).build();
	}
}





