package com.example.demo.exception;

public class BoardNotFoundException extends RuntimeException {
}
