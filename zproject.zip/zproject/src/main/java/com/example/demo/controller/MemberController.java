package com.example.demo.controller;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.time.*;

import javax.servlet.http.*;
import javax.validation.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.security.access.prepost.*;
import org.springframework.security.core.*;
import org.springframework.security.web.authentication.logout.*;
import org.springframework.stereotype.*;
import org.springframework.validation.*;
import org.springframework.validation.annotation.*;
import org.springframework.web.bind.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.controller.editor.*;
import com.example.demo.dto.*;
import com.example.demo.service.*;

@Validated
@Controller
public class MemberController {
	@Autowired
	private MemberService service;
	
	// 1. 데이터 입출력 방식을 지정
	// a. 스프링 입력 : 프로퍼티 에디터 작성
	// b. 스프링 출력 : 메시지 컨버터. JSON의 경우 jackson 어노테이션
	// c. 마이바티스 입출력 : TypeHandler
	@InitBinder
	public void init(WebDataBinder wdb) {
		wdb.registerCustomEditor(LocalDate.class, new MyDatePropertyEditor());
	}
	
	// job1. 아이디 중복 확인 - 예외상황을 if문 처리
	@GetMapping(path="/member/check/username", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> idCheck(String username) {
		service.idAvailable(username);
		return ResponseEntity.ok(new RestResponse("OK", "사용할 수 있는 아이디입니다", null));
	}
	
	// job2. 이메일 중복 확인
	@GetMapping(value="/member/check/email", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> emailCheck(String email) {
		service.emailAvailable(email);
		return ResponseEntity.ok(new RestResponse("OK", "사용할 수 있는 이메일입니다", null));
	}
	
	// job3. 회원 가입
	@PostMapping(value="/member/new", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> join(MemberDto.Join dto) {
		System.out.println("00000000000000000000000000000000000000000000");
		service.join(dto);
		System.out.println("11111111111111111111111111111111111111111111");
		return ResponseEntity.ok(new RestResponse("OK", "가입 성공", "/login"));
		
	}
	
	// job4. 내정보 보기
	@PreAuthorize("isAuthenticated()")
	@GetMapping(value="/member", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> read(Principal principal) {
		MemberDto.Read dto = service.read(principal.getName());
		return ResponseEntity.ok(new RestResponse("OK", dto, null));
	}
	
	// 확장자로 데이터의 MIME 타입을 리턴하는 함수
	// jpg, png, gif -> 확장자가 틀리면 브라우저가 제대로 처리못할수도????
	private MediaType getMediaType(String imagename) {
		// spring11.jpg -> .을 찾아서 .다음부터 자르면 확장자
		int position = imagename.lastIndexOf(".");
		String ext = imagename.substring(position+1).toUpperCase();
		if(ext.equals("JPG"))
			return MediaType.IMAGE_JPEG;
		else if(ext.equals("PNG"))
			return MediaType.IMAGE_PNG;
		else 
			return MediaType.IMAGE_GIF;
	}
	
	// job 5. 프사 보기
	@GetMapping(path="/profile/{imagename}", produces=MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<byte[]> showProfile(@PathVariable String imagename) {
		File file = new File("c:/upload/profile", imagename);
		if(file.exists()==false)
			return null;
		// 요청, 응답은 헤더와 바디로 구성
		// 헤더는 바디의 종류, 취급 방법등의 메타 데이터가 들어간다
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(getMediaType(imagename));
		
		// inline을 주면 브라우저 처리, attachment를 주면 다운로드
		headers.add("Content-Disposition", "inline;filename="+imagename);
		try {
			// 파일은 byte[]로 내보내면 된다
			// 파일을 byte의 배열로 바꾸는 방법들이 몇가지가 있는데 그 중
			// 한 줄짜리
			return ResponseEntity.ok().headers(headers)
					.body(Files.readAllBytes(file.toPath()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	// job 6. 이메일을 입력받아 아이디를 찾아서 이메일로 보낸다
	@GetMapping(path="/member/find/username", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> findId(@Valid MemberDto.FindId dto, BindingResult bindingResult) {
		service.findId(dto);
		return ResponseEntity.ok(new RestResponse("OK","아이디를 이메일로 보냈습니다", null));
	}
	
	// job 7. 아이디와 이메일을 입력받아 임시비밀번호를 이메일로 보낸다
	@PatchMapping(path="/member/find/password", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> resetPassword(@Valid MemberDto.ResetPassword dto, BindingResult bindingResult) {
		service.resetPassword(dto);
		return ResponseEntity.ok(new RestResponse("OK","아이디를 이메일로 보냈습니다", null));
	}
	
	// job 8. 비밀번호 변경
	@PreAuthorize("isAuthenticated()")
	@PatchMapping(path="/member/password", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> changePassword(@Valid MemberDto.ChangePassword dto, BindingResult bindingResult, Principal principal) {
		service.changePassword(dto, principal.getName());
		return ResponseEntity.ok(new RestResponse("OK","아이디를 이메일로 보냈습니다", null));
	}
	
	// job 9. 내정보 변경
	// 원래는 PutMapping -> PutMapping은 파일 업로드를 처리하지 못한다
	// 프사를 변경(파일 업로드)하려면 PostMapping으로 가야만 한다
	@PreAuthorize("isAuthenticated()")
	@PostMapping(path="/member", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> update(@Valid MemberDto.Update dto, BindingResult bindingResult, Principal principal) {
		service.update(dto, principal.getName());
		return ResponseEntity.ok(new RestResponse("OK", "정보를 변경했습니다", "/member/read"));
	}
	
	// job 10. 회원 탈퇴
	// 스프링 시큐리티로 로그아웃을 시킨다 - 이때 Authentication 객체 필요
	// Authentication - 인증 정보를 담은 객체
	// Principal - 로그인 아이디를 담고 있는 객체
	//           - 비로그인일 때 Authentication은 anonymousUser란 아이디를 가진다
	@PreAuthorize("isAuthenticated()")
	@DeleteMapping(path="/member", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> resign(SecurityContextLogoutHandler handler, HttpServletRequest req, HttpServletResponse res, 			Authentication authentication)  {
		service.resign(authentication.getName());
		handler.logout(req, res, authentication);
		return ResponseEntity.ok(new RestResponse("OK", "회원 정보를 삭제했습니다", "/member/list"));
	}
}







