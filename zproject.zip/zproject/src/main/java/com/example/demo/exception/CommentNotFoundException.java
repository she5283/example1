package com.example.demo.exception;

public class CommentNotFoundException extends RuntimeException {

}
