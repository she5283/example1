package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.seller.dao.SstoreDao;
import com.example.demo.seller.dao.sSellerDao;
import com.example.demo.seller.entity.Sseller;

@SpringBootTest
public class sellerTest {

	@Autowired
	sSellerDao dao;
	
	@Autowired
	SstoreDao storedao;
	
	//@Transactional
	//@Test
	public void savetest() {
		Sseller dto = Sseller.builder().sId("spring").sBuisnessNum("123456").sPassword("1234").sName("양씨").sBirth(LocalDate.of(1990, 1, 1)).sPhone("0101234").sEmail("aa@aaa.aaa").build();
		
		assertEquals(1, dao.sSellerJoin(dto));
	}
	
	//@Test
	public void readtest() {
		assertEquals("123456", dao.sellerAllread("spring").get().getSBuisnessNum());
		assertNotEquals("1234", dao.sellerAllread("spring").get().getSBuisnessNum());
	}
	
	@Transactional
	//@Test
	public void UpdateTest() {
		Sseller dto = Sseller.builder().sId("spring").sBuisnessNum("123456").sPassword("1234").sName("양씨").sBirth(LocalDate.of(1990, 1, 1)).sPhone("01012345678").sEmail("aa@aaa.aaa").build();
		
		assertEquals(1, dao.sSellerUpdate(dto));
	}
	
	@Transactional
	//@Test
	public void DeleteTest() {
		assertEquals(1, dao.sSellerDelete("spring"));
	}
	
	//@Test
	public void getlocation() {
		System.out.println(storedao.getLocation()); 
	}
	
	//@Test
	public void getCategory() {
		System.out.println(storedao.getCategory());
	}
}
