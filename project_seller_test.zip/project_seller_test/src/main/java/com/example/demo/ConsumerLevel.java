package com.example.demo;

public enum ConsumerLevel {
	Bronze, Gold, Diamond, GrandMaster, Challenger;
}
