package com.example.demo.seller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SellResponseDto {

	public String message;
	public Object result;
}
