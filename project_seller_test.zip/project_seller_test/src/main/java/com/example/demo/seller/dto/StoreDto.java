package com.example.demo.seller.dto;

import org.springframework.web.multipart.MultipartFile;

import com.example.demo.seller.entity.Sstore;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class StoreDto {
	
	@Data
	public static class LocationDto {
		private Integer sLocationCode;
		private String sLocationName;
	}
	
	@Data
	public static class CategoryDto {
		private Integer sCategoryNum;
		private String sCategoryName;
	}
	
	@Data
	public static class StoreSaveDto {
		private String sStoreName;
		private String sStoreAddress;
		private MultipartFile sStoreLogo;
		private Integer sMinDeleVery;
		private String sStoreTime;
		private Integer sCategoryNum;
		private Integer sLocationCode;
		private String sStoreIntro;
		
		public Sstore toEntity() {
			return Sstore.builder().sStoreName(sStoreName).sStoreAddress(sStoreAddress).sMinDeleVery(sMinDeleVery).sStoreTime(sStoreTime).sLocationCode(sLocationCode).sStoreIntro(sStoreIntro).sCategoryNum(sCategoryNum).build();
		}
	}
	
	@Data
	public static class StoreRead {
		private Integer sStoreNum;
		private String sStoreName;
		private String sStoreAddress;
		private String sStoreLogo;
		private Integer sMinDeleVery;
		private String sStoreTime;
		private Integer sStoreStatus;
		private String sId;
		private String sStoreIntro;
	}
}
