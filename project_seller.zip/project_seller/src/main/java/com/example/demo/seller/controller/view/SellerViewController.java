package com.example.demo.seller.controller.view;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SellerViewController {
	
	@GetMapping("/seller/seller/sellerjoin")
	public void sellerjoin() {
		
	}
	
	@GetMapping("/seller/seller/login")
	public void sellerlogin() {
		
	}
	
	@GetMapping("/seller/store/storeadd")
	public void storeadd() {
		
	}
	
	@GetMapping("/seller/store/storeread")
	public void storeread() {
		
	}

	@GetMapping("/seller/seller/home")
	public void loginclear() {
		
	}	
}
