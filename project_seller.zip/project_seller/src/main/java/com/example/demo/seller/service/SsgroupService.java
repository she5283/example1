package com.example.demo.seller.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.seller.dao.SmenuGroupDao;
import com.example.demo.seller.dto.SgroupDto;
import com.example.demo.seller.entity.SmenuGroup;

@Service
public class SsgroupService {
	
	@Autowired
	private SmenuGroupDao sgdao;
	
	public String addmenugroup(SgroupDto.SaveDto dto) {
		SmenuGroup smg = dto.toentity();
		sgdao.menugroupadd(smg);
		return "생성 완료";
	}
	
	public SmenuGroup readMenuGroup(Integer sGroupNum) {
		
		return sgdao.readGroup(sGroupNum).get();
	}
	
	public SmenuGroup updateMenuGroup(Integer sGroupNum, String sGroupName) {
		return null;
	}
}
