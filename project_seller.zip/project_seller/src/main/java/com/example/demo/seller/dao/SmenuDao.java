package com.example.demo.seller.dao;

import java.util.Optional;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.seller.dto.SmenuDto;
import com.example.demo.seller.entity.Smenu;

@Mapper
public interface SmenuDao {

	public Integer menuAdd(Smenu smenu);
	
	public Integer updateMenu(Smenu smenu);
	
	public Integer deleteMenu(Integer sMenuCode);
	
	public Optional<Smenu> readMenu(Integer sMenuCode);
	
	public Optional<SmenuDto.readMenuDto> groupmenuread(Integer sGroupNum);
	
}
