package com.example.demo.seller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.example.demo.seller.security.SellerLoginIdPwValidator;
import com.example.demo.seller.security.SellerSuccessHandler;


@Configuration
@EnableWebSecurity
public class SellerSecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private SellerLoginIdPwValidator sellerlogininfo;
		
	@Autowired
	private SellerSuccessHandler sellerSuccessHandler;
		
	public SellerSecurityConfig(SellerLoginIdPwValidator sellerloginIdPwValidator) {
		this.sellerlogininfo = sellerloginIdPwValidator;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
			
		http.csrf().disable();
			
		http.formLogin().loginPage("/seller/seller/login").loginProcessingUrl("/slogin").defaultSuccessUrl("/seller/seller/home").successHandler(sellerSuccessHandler)
		.usernameParameter("sId")
		.passwordParameter("sPassword")
		.and().logout().logoutUrl("/seller/logout").logoutSuccessUrl("/seller/seller/login").invalidateHttpSession(true);
			
		}
		
	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception{
		auth.userDetailsService(sellerlogininfo);
	}
		
}

