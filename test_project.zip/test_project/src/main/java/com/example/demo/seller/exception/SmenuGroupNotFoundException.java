package com.example.demo.seller.exception;

public class SmenuGroupNotFoundException  extends RuntimeException{

}
