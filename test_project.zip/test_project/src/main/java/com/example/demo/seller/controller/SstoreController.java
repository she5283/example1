package com.example.demo.seller.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.seller.dto.*;
import com.example.demo.seller.dto.SstoreDto.*;
import com.example.demo.seller.entity.*;
import com.example.demo.seller.service.*;

@Controller
public class SstoreController {

	@Autowired
	private SstoreService service;
	
	
	@PostMapping(value="/store/new" , produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Sstore> write(@ModelAttribute SstoreDto.write dto) {
		return ResponseEntity.ok(service.AddStore(dto));
	}
	
	@PutMapping(value="/store/update", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Integer> update (@ModelAttribute SstoreDto.update dto) {
		return ResponseEntity.ok(service.UpdateStore(dto));
	}
	
	@DeleteMapping(value="/store/delete", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Integer> delete(@ModelAttribute Integer sStoreNum) {
		return ResponseEntity.ok(service.DeleteStore(sStoreNum));
	}
	
	@GetMapping(value="/store" , produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Read> read(@ModelAttribute Integer sStoreNum) {
		Optional<Read> store = service.ReadStore(sStoreNum);
		return ResponseEntity.ok(store.get());
	}
	
	@PostMapping(value="/store/BnumOverlap")
	public Integer Overlap(@ModelAttribute Integer sStoreBNum) {
		Integer Bnum = service.OverlapStoreBNum(sStoreBNum);
		return Bnum;
	}
}
