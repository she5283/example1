package com.example.demo.seller.controller;

import java.security.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.security.access.prepost.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.seller.dto.*;
import com.example.demo.seller.service.*;

@Controller
public class SmenuGroupController {

	@Autowired
	private SmenuGroupService service;
	
	// 메뉴 그룹 상세정보 출력
	@PreAuthorize("isAuthenticated()")
	@GetMapping(value = "seller/menu/group/read", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> read(@RequestParam Integer sGroupNum, Principal principal) {
		principal.getName();
		return ResponseEntity.ok(new RestResponse("OK", service.read(sGroupNum), null));
	}
	
	// 메뉴 그룹 추가
	@PreAuthorize("isAuthenticated()")
	@PostMapping(value = "seller/menu/group/new", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> write(@ModelAttribute SmenuGroupDto.Write dto, Principal principal) {
		System.out.println(dto);
		System.out.println(principal.getName());
		return ResponseEntity.ok(new RestResponse("OK", service.write(dto, principal.getName()), null));
	}
	
	// 메뉴 그룹 변경
	@PreAuthorize("isAuthenticated()")
	@PutMapping(value = "seller/menu/group/update", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> update(@ModelAttribute SmenuGroupDto.Update dto, Principal principal) {
		System.out.println(dto);
		service.update(dto, principal.getName());
		return ResponseEntity.ok(new RestResponse("OK", "메뉴 그룹 변경", null));
	}
	
	// 메뉴 그룹 삭제
	@PreAuthorize("isAuthenticated()")
	@DeleteMapping(value = "seller/menu/group/delete", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> delete(@RequestParam Integer sGroupNum, Principal principal) {
		service.groupnumdelete(sGroupNum);
		service.delete(sGroupNum, principal.getName());
		return ResponseEntity.ok(new RestResponse("OK", "메뉴 그룹 삭제", null));
	}
	
	// 메뉴 그룹 출력
	@PreAuthorize("isAuthenticated()")
	@GetMapping(value = "seller/menu/group/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> list(@RequestParam Integer sStoreNum, Principal principal) {

		principal.getName();
		return ResponseEntity.ok(new RestResponse("OK", service.list(sStoreNum) , null));
	}
}
