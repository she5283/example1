package com.campass.demo.controlleradvice;

import java.sql.*;

import javax.validation.*;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.campass.demo.dto.*;
import com.campass.demo.exception.*;


@RestControllerAdvice
public class BoardControllerAdvice {

	
	@ExceptionHandler(JobFailException.class)
	public ResponseEntity<RestResponse> JFExption(JobFailException e) {
		System.out.println(e.getMessage());
		return ResponseEntity.status(HttpStatus.CONFLICT).body(new RestResponse("FAIL", e.getMessage(), null));
	}
	

}
