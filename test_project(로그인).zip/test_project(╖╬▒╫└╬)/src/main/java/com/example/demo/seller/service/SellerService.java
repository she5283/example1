package com.example.demo.seller.service;

public class SellerService {

}
