package com.example.demo.seller.entity;

import java.time.*;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
public class Seller {
	private String sId;
	private Integer sBusinessNum;
	private String sPassword;
	private String sName;
	private Integer sPhone;
	private String sEmail;
	
	private Integer sStoreNum;
	private LocalDate sBirth;
}
